# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['lootscraper',
 'lootscraper.alembic',
 'lootscraper.alembic.versions',
 'lootscraper.scraper',
 'lootscraper.scraper.info',
 'lootscraper.scraper.loot']

package_data = \
{'': ['*']}

install_requires = \
['SQLAlchemy>=1.4.45,<2.0.0',
 'Unidecode>=1.3.6,<2.0.0',
 'alembic>=1.9.0,<2.0.0',
 'feedgen>=0.9.0,<0.10.0',
 'httpx>=0.23.1,<0.24.0',
 'humanize>=4.4.0,<5.0.0',
 'playwright>=1.28.0,<2.0.0',
 'python-telegram-bot[rate-limiter]>=20.0a6,<21.0',
 'pytz>=2022.7,<2023.0',
 'xvfbwrapper>=0.2.9,<0.3.0']

setup_kwargs = {
    'name': 'lootscraper',
    'version': '1.0.0',
    'description': 'RSS feeds and Telegram bot for free game and loot offers.',
    'long_description': "# LootScraper\n\n![image](images/ls_2880x1024.png)\n\n[![Publish to Docker Hub](https://github.com/eikowagenknecht/lootscraper/actions/workflows/publish_docker_hub.yml/badge.svg)](https://github.com/eikowagenknecht/lootscraper/actions/workflows/publish_docker_hub.yml)\n[![Publish to Github Packages](https://github.com/eikowagenknecht/lootscraper/actions/workflows/publish_github_packages.yml/badge.svg)](https://github.com/eikowagenknecht/lootscraper/actions/workflows/publish_github_packages.yml)\n[![CC BY-NC-SA 4.0][cc-by-nc-sa-shield]][cc-by-nc-sa]\n\nYou enjoy getting games for free but you *don’t* enjoy having to keep track of the various sources (Amazon Prime, Epic Games, Steam, ...) for free offers? Also your F5 key starts to look a bit worn out? Then this is for you!\n\n## Public feeds / channels / bots\n\nLet's be honest, you're probably not here because you are interested in the technical details of how this works. You just want free games. And that's fine. So without further ado, here's where you find them!\n\n### Telegram channels\n\nWant to get a Telegram notification each time a new offer is discovered? Just subscribe to the Telegram channels.\n\n- Amazon Prime ([games](https://t.me/free_amazon_games_ls) and [ingame loot](https://t.me/free_amazon_loot_ls))\n- [Epic Games](https://t.me/free_epic_games_ls)\n- [Gog games](https://t.me/free_gog_games_ls)\n- [Humble games](https://t.me/free_humble_games_ls)\n- [itch.io games](https://t.me/free_itch_games_ls)\n- Steam ([games](https://t.me/free_steam_games_ls) and [ingame loot](https://t.me/+ENZ8x3Ec1dwxMThi))\n\nFor our mobile gamers:\n\n- [Apple iPhone games](https://t.me/+SOF7VjGTGPw1OTAy)\n- [Google Android games](https://t.me/+Vma9PScf1uY3M2Uy)\n\n### Telegram bot\n\nWant to receive only the offers *you* want in one single chat? Subscribe directly to the source: The [Telegram LootScraperBot](https://t.me/LootScraperBot) will happily send you push notifications for new offers. You can choose which categories to subscribe there.\n\nThis is what it currently looks like in Telegram:\n\n![image](https://user-images.githubusercontent.com/1475672/166058823-98e2beb9-7eb5-403d-94c7-7e17966fe9b7.png)\n\n### RSS feeds\n\nYou prefer the anonymity and manageability of RSS feeds? Sure. You can use the links below.\n\n- Amazon Prime ([games](https://feed.phenx.de/lootscraper_amazon_game.xml) and [ingame loot](https://feed.phenx.de/lootscraper_amazon_loot.xml))\n- [Epic Games](https://feed.phenx.de/lootscraper_epic_game.xml)\n- [Gog games](https://feed.phenx.de/lootscraper_gog_game.xml)\n- [Humble games](https://feed.phenx.de/lootscraper_humble_game.xml)\n- [itch.io games](https://feed.phenx.de/lootscraper_itch_game.xml)\n- Steam ([games](https://feed.phenx.de/lootscraper_steam_game.xml) and [ingame loot](https://feed.phenx.de/lootscraper_steam_loot.xml))\n\nFor our mobile gamers:\n\n- [Apple iPhone games](https://feed.phenx.de/lootscraper_apple_game.xml)\n- [Google Android games](https://feed.phenx.de/lootscraper_google_game.xml)\n\nIf you want *everything* in one feed, use [this link](https://feed.phenx.de/lootscraper.xml). If you want to get the offers by email instead, you can use free services like <https://blogtrottr.com/> or <https://feedsub.com/> to convert from RSS to email.\n\nThis is what it currently looks like in Feedly:\n\n![image](https://user-images.githubusercontent.com/1475672/161056100-2fcf005f-19a9-4279-a2d3-5a90855426ff.png)\n\n## How this works\n\nThis Python (3.10+) application uses Selenium to automatically visit sites with free gaming related offers (currently Amazon Prime, Epic Games and Steam are supported, more will follow) and then neatly puts the gathered information into RSS feeds and a Telegram bot. So now you can track the offers using your favorite news reader like Feedly instead of manually visiting the sites or get a message every time a new offer is available.\n\nIf you encounter any problems feel free to open an issue here and I'll try my best to help. I'd also really like to hear your feature requests (even though I still have quite some ideas myself)!. This is tracked in the Github issues as well.\n\n### For power users and developers\n\nYou can either run this project locally on your computer or in any environment capable of running a Docker container.\n\nIf you want to do so or even contribute, please see the [README for developers](README_DEV.md) file.\n\n## License\n\n[![CC BY-NC-SA 4.0][cc-by-nc-sa-image]][cc-by-nc-sa]\n\nThis work is licensed under a\n[Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License][cc-by-nc-sa].\n\n[cc-by-nc-sa]: http://creativecommons.org/licenses/by-nc-sa/4.0/\n[cc-by-nc-sa-image]: https://licensebuttons.net/l/by-nc-sa/4.0/88x31.png\n[cc-by-nc-sa-shield]: https://img.shields.io/badge/License-CC%20BY--NC--SA%204.0-lightgrey.svg\n",
    'author': 'Eiko Wagenknecht',
    'author_email': 'git@eiko-wagenknecht.de',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'https://github.com/eikowagenknecht/lootscraper',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.11,<4.0',
}


setup(**setup_kwargs)
